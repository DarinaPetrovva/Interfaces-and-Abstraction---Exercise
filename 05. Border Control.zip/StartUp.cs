﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            List<IIdentifiable> all = new List<IIdentifiable>();

            string command;

            while ((command = Console.ReadLine()) != "End")
            {
                var input = command.Split();

                if (input.Length == 3)
                {
                    Citizen citizen = new Citizen(input[0],int.Parse(input[1]), input[2]);
                    all.Add(citizen);


                }
                else if (input.Length == 2)
                {
                    Robot robot = new Robot(input[0], input[1]);
                    all.Add(robot);
                }
                
            }

            var lastdigits = Console.ReadLine();

            all.Where(c => c.Id.EndsWith(lastdigits))
            .Select(c => c.Id)
            .ToList()
            .ForEach(Console.WriteLine);



        }
    }
}
